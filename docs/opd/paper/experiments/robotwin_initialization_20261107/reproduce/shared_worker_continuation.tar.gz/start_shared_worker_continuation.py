import subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent
for script,logname in [('shared_worker_continue.py','shared_worker_continue.log'),('finalize_shared_worker_continuation.py','shared_worker_continue_finalize.log')]:
 if 'finalize' in script:
  deadline=time.monotonic()+60
  while not (p/'shared_worker_eval_action20_20261107_r4/status.json').exists():
   if time.monotonic()>deadline:raise TimeoutError('queue did not create state')
   time.sleep(1)
 with (p/logname).open('x') as log:
  child=subprocess.Popen(['bash',str(p/'shared_worker_env.sh'),str(p/script)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 print(script,child.pid,flush=True)
