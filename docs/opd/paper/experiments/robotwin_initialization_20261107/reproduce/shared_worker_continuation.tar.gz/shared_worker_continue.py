"""Action20: paired worker parity gate, then fixed50 teacher/student validation."""
import json,os,socket,subprocess,sys,time,traceback
from pathlib import Path
STUDY=Path(__file__).resolve().parent
REPO=STUDY.parents[2]/'outputs/worktrees/robotwin_task_init_probe'
OUT=STUDY/'shared_worker_eval_action20_20261107_r4'
OUT.mkdir(exist_ok=True)
TASKS=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two']
TEACHERS={t:STUDY/('candidate' if t=='open_laptop' else 'candidate_dump_bin_bigbin')/'torch'/t if t in ('open_laptop','dump_bin_bigbin') else Path('/localscratch2/liyifa11/XyFile/opd-robotwin4/models/pi05_pace_torch')/t for t in TASKS}
WRAPPER=['bash',str(STUDY/'shared_worker_env.sh')]
state={'status':'WAITING_RUNTIME','pid':os.getpid(),'host':socket.gethostname(),'completed':[]};active={}
def save():
 state['updated_unix']=time.time();state['active']=[dict(gpu=g,pid=c.pid,label=label) for g,(c,label) in active.items()]
 p=OUT/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(p)
def worker_command(task,checkpoint,episodes,gpu,output,pool,trace=False):
 cmd=WRAPPER+[str(REPO/'toolkits/robotwin_mopd/worker_evaluate.py'),'--task',task,'--tasks',*TASKS,'--pool',str(pool),'--checkpoint',str(checkpoint),'--episodes',str(episodes),'--gpu',str(gpu),'--output',str(output)]
 for t,p in TEACHERS.items():cmd+=['--norm-stats',f'{t}={p}/assets/robotwin/norm_stats.json']
 if trace:cmd+=['--trace-actions']
 return cmd
def launch(cmd,gpu,label,extra_env=None):
 with (OUT/f'{label}.log').open('x') as log:
  child=subprocess.Popen(cmd,cwd=REPO,env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu),**(extra_env or {})},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 active[gpu]=(child,label);save()
def wait_active():
 while active:
  for gpu,(child,label) in list(active.items()):
   if child.poll() is not None:
    del active[gpu];state['completed'].append(dict(label=label,returncode=child.returncode));save()
    if child.returncode:raise RuntimeError(f'{label} failed, code={child.returncode}')
  if active:time.sleep(20)
import ray,tempfile
try:
 assert socket.gethostname().split('.')[0]=='action20'
 previous=STUDY/'shared_worker_eval_action20_20261107_r3'
 for name in ['development50.json','paired_parity.json','paired_worker','paired_legacy.json','teacher_open_laptop','teacher_handover_mic']:
  target=OUT/name
  if not target.exists():target.symlink_to(previous/name)
 for label in ['teacher_open_laptop','teacher_handover_mic']:
  report=json.loads((OUT/label/'summary.json').read_text())
  assert report['completed_episodes']==50
  state['completed'].append(dict(label=label,returncode=0,successes=report['successes'],episodes=50,reused_from=str(previous)))
 state['status']='STARTING_PERSISTENT_RAY';save()
 context=ray.init(address='local',namespace='robotwin-eval-supervisor',num_cpus=16,num_gpus=2,object_store_memory=2*1024**3,include_dashboard=False,_temp_dir=tempfile.mkdtemp(prefix='rwt-eval-'))
 os.environ['RAY_ADDRESS']=context.address_info['gcs_address']
 state['ray_address']=os.environ['RAY_ADDRESS'];state['ray_owner_pid']=os.getpid()
 deadline=time.monotonic()+12*3600
 pool=OUT/'development50.json'
 state['status']='VALIDATING_SETTING';save()
 pending=[('teacher','dump_bin_bigbin'),('teacher','stack_bowls_two')]+[('student400',t) for t in TASKS]
 while pending or active:
  for gpu,(child,label) in list(active.items()):
   if child.poll() is not None:
    del active[gpu]
    if child.returncode:raise RuntimeError(f'{label} failed: {child.returncode}')
    report=json.loads((OUT/label/'summary.json').read_text())
    state['completed'].append(dict(label=label,returncode=0,successes=report['successes'],episodes=report['completed_episodes']));save()
  for gpu in (0,1):
   if gpu in active or not pending:continue
   free=int(subprocess.check_output(['nvidia-smi',f'--id={gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
   if free<35000:continue
   kind,task=pending.pop(0);label=f'{kind}_{task}'
   checkpoint=TEACHERS[task] if kind=='teacher' else STUDY/'student400_bundle'
   launch(worker_command(task,checkpoint,50,gpu,OUT/label,pool),gpu,label)
  if time.monotonic()>deadline:raise TimeoutError('validation budget')
  if pending or active:time.sleep(20)
 state['status']='COMPLETE';save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());save();raise
finally:
 for child,label in active.values():
  if child.poll() is None:child.terminate()

 ray.shutdown()
