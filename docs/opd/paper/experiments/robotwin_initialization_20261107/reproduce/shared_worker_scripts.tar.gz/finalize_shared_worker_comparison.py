"""Wait for the fixed50 worker queue, then retain a paired cross-host comparison."""
import csv,json,time,traceback
from pathlib import Path
study=Path(__file__).resolve().parent
out=study/'shared_worker_eval_action20_20261107_r3'
tasks=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two']
try:
 deadline=time.monotonic()+12*3600
 while True:
  state=json.loads((out/'status.json').read_text())
  if state['status']=='FAILED':raise RuntimeError(state['error'])
  if state['status']=='COMPLETE':break
  if time.monotonic()>deadline:raise TimeoutError('evaluation comparison wait')
  time.sleep(30)
 rows=[];details={}
 for kind in ['teacher','student400']:
  for task in tasks:
   if kind=='student400':old_paths=[study/'replacement_eval400'/f'{task}.json',study/'validation400'/f'student400_{task}.json']
   else:
    first=study/'candidate/teacher_dev20.json' if task=='open_laptop' else study/'candidate_dump_bin_bigbin/teacher_dev20.json' if task=='dump_bin_bigbin' else study/'retained_teacher_eval'/f'{task}.json'
    old_paths=[first,study/'validation400'/f'teachers_{task}.json']
   old=[row for path in old_paths for row in json.loads(path.read_text())['episodes']]
   new=json.loads((out/f'{kind}_{task}'/'summary.json').read_text())['episodes']
   assert len(old)==len(new)==50
   old_by_seed={r['actual_reset_seed']:r for r in old}
   assert len(old_by_seed)==50
   outcome_changes=[];control_changes=[]
   for row in new:
    previous=old_by_seed[row['actual_reset_seed']]
    for field in ['instruction','actual_scene_info']:assert row[field]==previous[field],(kind,task,field,row['actual_reset_seed'])
    if row['success_once']!=previous['success_once']:outcome_changes.append(row['actual_reset_seed'])
    if row['simulation_steps']!=previous['simulation_steps']:control_changes.append(row['actual_reset_seed'])
   old_sr=sum(r['success_once'] for r in old);new_sr=sum(r['success_once'] for r in new)
   rows.append(dict(model=kind,task=task,old_successes=old_sr,new_successes=new_sr,episodes=50,delta_pp=2*(new_sr-old_sr),paired_outcome_changes=len(outcome_changes),control_count_changes=len(control_changes),fixed_identity_match=True))
   details[f'{kind}_{task}']=dict(outcome_changed_seeds=outcome_changes,control_count_changed_seeds=control_changes,legacy_results=[str(p) for p in old_paths])
 with (out/'setting_comparison.csv').open('w',newline='') as stream:
  writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
 report=dict(rows=rows,details=details,macro_sr={kind:sum(r['new_successes'] for r in rows if r['model']==kind)/200 for kind in ['teacher','student400']},interpretation='New standard-worker action20 evaluation versus legacy action00 development results; any changes combine host/device and execution-path effects. Two-scene same-host action-level parity passed separately.')
 (out/'setting_comparison.json').write_text(json.dumps(report,indent=2)+'\n')
 (out/'comparison_status.json').write_text(json.dumps(dict(status='COMPLETE',finished_unix=time.time()),indent=2)+'\n')
except BaseException as error:
 (out/'comparison_status.json').write_text(json.dumps(dict(status='FAILED',error=repr(error),traceback=traceback.format_exc()),indent=2)+'\n')
 raise
