"""Action20: paired worker parity gate, then fixed50 teacher/student validation."""
import json,os,socket,subprocess,sys,time,traceback
from pathlib import Path
STUDY=Path(__file__).resolve().parent
REPO=STUDY.parents[2]/'outputs/worktrees/robotwin_task_init_probe'
OUT=STUDY/'shared_worker_eval_action20_20261107_r3'
OUT.mkdir(exist_ok=True)
TASKS=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two']
TEACHERS={t:STUDY/('candidate' if t=='open_laptop' else 'candidate_dump_bin_bigbin')/'torch'/t if t in ('open_laptop','dump_bin_bigbin') else Path('/localscratch2/liyifa11/XyFile/opd-robotwin4/models/pi05_pace_torch')/t for t in TASKS}
WRAPPER=['bash',str(STUDY/'shared_worker_env.sh')]
state={'status':'WAITING_RUNTIME','pid':os.getpid(),'host':socket.gethostname(),'completed':[]};active={}
def save():
 state['updated_unix']=time.time();state['active']=[dict(gpu=g,pid=c.pid,label=label) for g,(c,label) in active.items()]
 p=OUT/'status.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(p)
def worker_command(task,checkpoint,episodes,gpu,output,pool,trace=False):
 cmd=WRAPPER+[str(REPO/'toolkits/robotwin_mopd/worker_evaluate.py'),'--task',task,'--tasks',*TASKS,'--pool',str(pool),'--checkpoint',str(checkpoint),'--episodes',str(episodes),'--gpu',str(gpu),'--output',str(output)]
 for t,p in TEACHERS.items():cmd+=['--norm-stats',f'{t}={p}/assets/robotwin/norm_stats.json']
 if trace:cmd+=['--trace-actions']
 return cmd
def launch(cmd,gpu,label,extra_env=None):
 with (OUT/f'{label}.log').open('x') as log:
  child=subprocess.Popen(cmd,cwd=REPO,env={**os.environ,'CUDA_VISIBLE_DEVICES':str(gpu),**(extra_env or {})},stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
 active[gpu]=(child,label);save()
def wait_active():
 while active:
  for gpu,(child,label) in list(active.items()):
   if child.poll() is not None:
    del active[gpu];state['completed'].append(dict(label=label,returncode=child.returncode));save()
    if child.returncode:raise RuntimeError(f'{label} failed, code={child.returncode}')
  if active:time.sleep(20)
try:
 assert socket.gethostname().split('.')[0]=='action20'
 deadline=time.monotonic()+12*3600;save()
 while True:
  setup=json.loads((STUDY/'action20_sim_setup_status.json').read_text())
  if setup['status']=='FAILED':raise RuntimeError(setup)
  if setup['status']=='COMPLETE':break
  if time.monotonic()>deadline:raise TimeoutError('runtime copy')
  time.sleep(20)
 state['status']='PAIRED_SMOKE';save()
 pool=STUDY/'replacement_dev20.json'
 launch(worker_command('stack_bowls_two',TEACHERS['stack_bowls_two'],2,0,OUT/'paired_worker',pool,True),0,'paired_worker')
 overrides=[]
 for t,p in TEACHERS.items():
  prefix='+' if t in ('open_laptop','dump_bin_bigbin') else ''
  overrides += ['--override',f'{prefix}rollout.expert_models.{t}.model_path={p}','--override',f'{prefix}actor.model.opd_task_norm_stats.{t}={p}/assets/robotwin/norm_stats.json']
 overrides+=['--override','~actor.model.opd_task_norm_stats.adjust_bottle','--override','~actor.model.opd_task_norm_stats.place_container_plate']
 legacy=WRAPPER+[str(STUDY/'legacy_trace_adapter.py'),'eval','--task','stack_bowls_two','--checkpoint',str(TEACHERS['stack_bowls_two']),'--episodes','2','--evaluation-pool',str(pool),'--output',str(OUT/'paired_legacy.json'),*overrides]
 launch(legacy,1,'paired_legacy',{'LEGACY_TRACE_PATH':str(OUT/'paired_legacy_actions.jsonl')})
 wait_active()
 state['status']='CHECKING_PARITY';save()
 # Use the runtime Python for numpy, not system Python.
 with (OUT/'paired_comparison.log').open('x') as log:
  subprocess.run(WRAPPER+[str(STUDY/'compare_worker_parity.py'),str(OUT)],cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
 state['status']='BUILDING_FIXED50_POOL';save()
 pool=OUT/'development50.json'
 cmd=WRAPPER+[str(REPO/'toolkits/robotwin_mopd/author_pool.py'),'--reference-root',str(STUDY.parents[2]/'outputs/robotwin4/reference/PACE-fd2e624'),'--output',str(pool),'--cohort','0','--start','0','--count','50','--purpose','development','--task-names',*TASKS,'--override','+env.eval.task_horizons.open_laptop=700','--override','+env.eval.task_horizons.dump_bin_bigbin=600']
 with (OUT/'pool_build.log').open('x') as log:subprocess.run(cmd,cwd=REPO,stdout=log,stderr=subprocess.STDOUT,check=True)
 state['status']='VALIDATING_SETTING';save()
 pending=[(kind,task) for kind in ('teacher','student400') for task in TASKS]
 while pending or active:
  for gpu,(child,label) in list(active.items()):
   if child.poll() is not None:
    del active[gpu]
    if child.returncode:raise RuntimeError(f'{label} failed: {child.returncode}')
    report=json.loads((OUT/label/'summary.json').read_text())
    state['completed'].append(dict(label=label,returncode=0,successes=report['successes'],episodes=report['completed_episodes']));save()
  for gpu in (0,1):
   if gpu in active or not pending:continue
   free=int(subprocess.check_output(['nvidia-smi',f'--id={gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
   if free<35000:continue
   kind,task=pending.pop(0);label=f'{kind}_{task}'
   checkpoint=TEACHERS[task] if kind=='teacher' else STUDY/'student400_bundle'
   launch(worker_command(task,checkpoint,50,gpu,OUT/label,pool),gpu,label)
  if time.monotonic()>deadline:raise TimeoutError('validation budget')
  if pending or active:time.sleep(20)
 state['status']='COMPLETE';save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());save();raise
finally:
 for child,label in active.values():
  if child.poll() is None:child.terminate()
