#!/bin/bash
set -euo pipefail
source /localscratch2/liyifa11/XyFile/opd-robotwin4/env.sh
export REPO_PATH=/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try/outputs/worktrees/robotwin_task_init_probe
export EMBODIED_PATH="$REPO_PATH/examples/embodiment"
export PYTHONPATH="$REPO_PATH:$PYTHONPATH"
export PACE_REFERENCE_ROOT=/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try/outputs/robotwin4/reference/PACE-fd2e624
export TORCHINDUCTOR_COMPILE_THREADS=1
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 USE_TF=0 JAX_PLATFORMS=cpu WANDB_MODE=disabled
cd "$REPO_PATH"
exec python -u "$@"
