"""Instrument the legacy evaluator without modifying its execution logic."""
import json,os,runpy,sys
from pathlib import Path
from toolkits.robotwin_mopd import evaluate
from toolkits.robotwin_mopd.worker_evaluate import observation_digest
import numpy as np
original=evaluate.get_model
trace=Path(os.environ['LEGACY_TRACE_PATH'])
counter=0
last_seed=None
def traced_model(cfg):
 model=original(cfg)
 original_predict=model.predict_action_batch
 def predict(env_obs,*a,**kw):
  import torch
  global counter,last_seed
  seed=int(torch.initial_seed())
  if seed!=last_seed:counter=0;last_seed=seed
  digest=observation_digest(env_obs)
  actions,result=original_predict(env_obs,*a,**kw)
  array=actions.detach().cpu().numpy() if hasattr(actions,'detach') else np.asarray(actions)
  with trace.open('a') as f:f.write(json.dumps(dict(scene_seed=seed,chunk=counter,observation_sha256=digest,actions=array.tolist()))+'\n')
  counter+=1
  return actions,result
 model.predict_action_batch=predict
 return model
evaluate.get_model=traced_model
runpy.run_path(str(Path(__file__).resolve().parent/'replacement_eval_adapter.py'),run_name='__main__')
