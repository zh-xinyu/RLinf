import json,sys
from pathlib import Path
import numpy as np
out=Path(sys.argv[1]);new=json.loads((out/'paired_worker/summary.json').read_text());old=json.loads((out/'paired_legacy.json').read_text())
fields=['actual_reset_seed','instruction','actual_scene_info','success_once','simulation_steps']
audit={'episodes':len(new['episodes']),'episode_field_matches':[],'trace':[]}
for a,b in zip(new['episodes'],old['episodes'],strict=True):
 matches={k:a[k]==b[k] for k in fields};audit['episode_field_matches'].append(matches)
nt=[json.loads(x) for x in (out/'paired_worker/actions.jsonl').read_text().splitlines()];ot=[json.loads(x) for x in (out/'paired_legacy_actions.jsonl').read_text().splitlines()]
all_query_count=len(nt)
steps={r['actual_reset_seed']:r['simulation_steps'] for r in new['episodes']}
nt=[r for r in nt if r['chunk'] < (steps[r['scene_seed']]+24)//25]
audit['all_worker_queries']=all_query_count
audit['chunk_counts']=[len(nt),len(ot)]
for a,b in zip(nt,ot):
 audit['trace'].append(dict(scene_seed_match=a['scene_seed']==b['scene_seed'],chunk_match=a['chunk']==b['chunk'],observation_match=a['observation_sha256']==b['observation_sha256'],action_max_abs=float(np.abs(np.asarray(a['actions'])-np.asarray(b['actions'])).max())))
audit['passed']=(len(nt)==len(ot) and all(all(v.values()) for v in audit['episode_field_matches']) and all(r['scene_seed_match'] and r['chunk_match'] and r['observation_match'] and r['action_max_abs']<=1e-5 for r in audit['trace']))
(out/'paired_parity.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit,indent=2))
if not audit['passed']:raise RuntimeError('Shared-worker vs legacy parity gate failed; inspect traces before full50')
