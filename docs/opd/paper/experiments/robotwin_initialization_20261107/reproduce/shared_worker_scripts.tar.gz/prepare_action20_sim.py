import subprocess,json,time
from pathlib import Path
study=Path(__file__).resolve().parent
runtime=Path('/localscratch2/liyifa11/XyFile/opd-robotwin4')
state={'status':'COPYING','started_unix':time.time()}
def save():
 (study/'action20_sim_setup_status.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 with (study/'action20_sim_setup.log').open('x') as log:
  for relative in ['env.sh','repos/RoboTwin/','cache/openpi/','models/pi05_pace_torch/handover_mic/','models/pi05_pace_torch/stack_bowls_two/']:
   dest=runtime/relative
   dest.parent.mkdir(parents=True,exist_ok=True)
   state['copying']=relative;save()
   subprocess.run(['rsync','-a','--exclude','outputs/','--exclude','__pycache__/',f'action00:{runtime}/{relative}',str(dest)+('/' if relative.endswith('/') else '')],stdout=log,stderr=subprocess.STDOUT,check=True)
 state.update(status='COMPLETE',finished_unix=time.time());save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e));save();raise
