import subprocess,socket
from pathlib import Path
p=Path(__file__).resolve().parent;host=socket.gethostname().split('.')[0]
with (p/f'uniform_supervisor_{host}.retry.log').open('x') as log:
 c=subprocess.Popen(['bash',str(p/'activate.sh'),str(p/'run_uniform.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(host,c.pid)
