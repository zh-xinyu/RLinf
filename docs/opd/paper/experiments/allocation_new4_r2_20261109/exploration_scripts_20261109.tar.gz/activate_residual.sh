#!/bin/bash
set -euo pipefail
case "$(hostname -s)" in
 action30) source /localscratch/liyifa11/XyFile/opd-robotwin4-action30-20261106/env.sh ;;
 action10) source /localscratch/liyifa11/XyFile/opd-robotwin4-action10-20261108/env.sh ;;
 *) exit 2 ;;
esac
source /egr/research-actionlab/liyifa11/XyCode/.wandb_env
export REPO_PATH=/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try/outputs/worktrees/robotwin_allocation_residual
export EMBODIED_PATH="$REPO_PATH/examples/embodiment"
export PYTHONPATH="$REPO_PATH:$PYTHONPATH"
export USE_TF=0 TORCHINDUCTOR_COMPILE_THREADS=1
cd "$REPO_PATH"
exec python -u "$@"
