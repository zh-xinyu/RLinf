"""Fixed development-only evaluation queue, standard workers, one persistent owner."""
import json,os,socket,subprocess,sys,tempfile,time,traceback
from pathlib import Path
import ray
from omegaconf import OmegaConf
S=Path(__file__).resolve().parent;OUT=S.parent;D=OUT/'development_action30';D.mkdir(exist_ok=True);TASKS=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two'];REPO=Path(os.environ['REPO_PATH']);active={}
state={'status':'BUILDING_POOL','pid':os.getpid(),'completed':[]}
def save():
 state['updated']=time.time();(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def evaluate(label,checkpoints,env,pool,cfg):
 state['status']='EVALUATING';state['current']=label;save()
 for gpu,task in enumerate(TASKS):
  destination=D/label/task
  cmd=[sys.executable,str(REPO/'toolkits/robotwin_mopd/worker_evaluate.py'),'--task',task,'--tasks',*TASKS,'--pool',str(pool),'--checkpoint',str(checkpoints[task]),'--episodes','20','--gpu',str(gpu),'--output',str(destination)]
  for t,p in cfg.actor.model.opd_task_norm_stats.items():cmd+=['--norm-stats',f'{t}={p}']
  destination.parent.mkdir(exist_ok=True)
  with (D/f'{label}_{task}.log').open('x') as f:
   child=subprocess.Popen(cmd,env={**env,'CUDA_VISIBLE_DEVICES':str(gpu)},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
  active[task]=child
 while active:
  for task,child in list(active.items()):
   if child.poll() is not None:
    if child.returncode:raise RuntimeError(f'{label}/{task} failed: {child.returncode}')
    del active[task]
  time.sleep(30)
 reports={t:json.loads((D/label/t/'summary.json').read_text()) for t in TASKS}
 scores={t:r['successes']/20 for t,r in reports.items()}
 report={'label':label,'task_sr':scores,'macro_sr':sum(scores.values())/4,'episodes_per_task':20,'control_steps':sum(r['simulation_steps'] for r in reports.values())}
 if label!='teachers':
  teachers=json.loads((D/'teachers/summary.json').read_text())['task_sr'];gaps={t:max(0,teachers[t]-scores[t]) for t in TASKS};report.update(positive_teacher_gaps=gaps,max_teacher_gap=max(gaps.values()),all_within_delta_010=all(scores[t]>=teachers[t]-.1 for t in TASKS))
 (D/label/'summary.json').write_text(json.dumps(report,indent=2)+'\n');state['completed'].append(report);save()
try:
 assert socket.gethostname().split('.')[0]=='action30';save()
 cfg=OmegaConf.load(OUT/'action30_uniform_train/resolved_config.yaml');pool=D/'development20.json'
 with (D/'pool_build.log').open('x') as log:
  subprocess.run([sys.executable,str(REPO/'toolkits/robotwin_mopd/author_pool.py'),'--reference-root',str(OUT.parents[2]/'outputs/robotwin4/reference/PACE-fd2e624'),'--output',str(pool),'--cohort','0','--start','0','--count','20','--purpose','development','--task-names',*TASKS,'--override','+env.eval.task_horizons.open_laptop=700','--override','+env.eval.task_horizons.dump_bin_bigbin=600'],stdout=log,stderr=subprocess.STDOUT,check=True)
 context=ray.init(address='local',namespace='allocation-dev-eval-owner',num_cpus=12,num_gpus=4,object_store_memory=2*1024**3,include_dashboard=False,_temp_dir=tempfile.mkdtemp(prefix='rwt-dev-'))
 env={**os.environ,'RAY_ADDRESS':context.address_info['gcs_address'],'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','TORCHINDUCTOR_COMPILE_THREADS':'1'}
 evaluate('teachers',{t:cfg.rollout.expert_models[t].model_path for t in TASKS},env,pool,cfg)
 evaluate('initial400',{t:cfg.actor.model.model_path for t in TASKS},env,pool,cfg)
 pending=[('uniform',10),('uniform',30),('residual',10),('residual',30),('sr',10),('sr',30)];deadline=time.monotonic()+18*3600
 while pending:
  ready=[]
  for method,round_ in pending:
   host='action10' if method=='residual' else 'action30';status=OUT/f'{host}_{method}_status.json'
   if not status.exists():continue
   record=json.loads(status.read_text())
   if record['status']=='FAILED':raise RuntimeError(f'{method} training failed')
   directory=Path(record.get('run_directory',''))/'checkpoints'/f'global_step_{round_*2}'
   # Runner state is written after complete actor+optimizer checkpoint save.
   if (directory/'runner_state.json').is_file() and (directory/'actor/dcp_checkpoint/.metadata').is_file():ready.append((method,round_,directory))
  if ready:
   method,round_,checkpoint=ready[0];evaluate(f'{method}_round{round_}',{t:checkpoint for t in TASKS},env,pool,cfg);pending.remove((method,round_))
  else:
   state.update(status='WAITING_CHECKPOINTS',pending=pending,current=None);save();time.sleep(60)
  if time.monotonic()>deadline:raise TimeoutError('development evaluation wait')
 state.update(status='COMPLETE',current=None);save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());save();raise
finally:
 for child in active.values():
  if child.poll() is None:child.terminate()
 ray.shutdown()
