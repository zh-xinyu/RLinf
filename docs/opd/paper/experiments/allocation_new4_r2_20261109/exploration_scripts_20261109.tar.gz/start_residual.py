import subprocess,socket
from pathlib import Path
p=Path(__file__).resolve().parent;host=socket.gethostname().split('.')[0]
with (p/f'residual_supervisor_{host}.micro8_retry2.log').open('x') as log:
 c=subprocess.Popen(['bash',str(p/'activate_residual.sh'),str(p/'run_residual.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(host,c.pid)
