import json,os,socket,subprocess,sys,tempfile,time,traceback
from pathlib import Path
import ray
from omegaconf import OmegaConf
from rlinf.utils.rollout_allocation import training_signature,load_teacher_reference
S=Path(__file__).resolve().parent;OUT=S.parent;C=OUT/'calibration_action30';C.mkdir(exist_ok=True)
TASKS=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two'];horizons=dict(zip(TASKS,[700,600,600,900]));active={};state={'status':'STARTING','pid':os.getpid(),'completed':[]}
def save():
 state['updated']=time.time();(C/'status.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 assert socket.gethostname().split('.')[0]=='action30'
 cfg=OmegaConf.load(OUT/'action30_uniform_train/resolved_config.yaml')
 plan={'protocol':{'name':'training_distribution_seen_unfiltered','episodes_per_task':20,'task_names':TASKS,'task_horizons':horizons,'instruction_type':'seen','reset_rule':'seed42 + global_task_id*1000003 + occurrence; native unstable-scene retry only'},'pool_content_sha256':None}
 import hashlib
 plan['pool_content_sha256']=hashlib.sha256(json.dumps(plan['protocol'],sort_keys=True).encode()).hexdigest()
 (C/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');save()
 context=ray.init(address='local',namespace='allocation-calibration-owner',num_cpus=12,num_gpus=4,object_store_memory=2*1024**3,include_dashboard=False,_temp_dir=tempfile.mkdtemp(prefix='rwt-calib-'))
 env={**os.environ,'RAY_ADDRESS':context.address_info['gcs_address'],'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','TORCHINDUCTOR_COMPILE_THREADS':'1'}
 started=time.time();state['status']='RUNNING';state['ray_address']=env['RAY_ADDRESS'];save()
 for gpu,task in enumerate(TASKS):
  cmd=[sys.executable,str(S/'calibration_worker_eval.py'),'--task',task,'--tasks',*TASKS,'--pool',str(C/'plan.json'),'--checkpoint',cfg.rollout.expert_models[task].model_path,'--episodes','20','--gpu',str(gpu),'--output',str(C/task)]
  for t,path in cfg.actor.model.opd_task_norm_stats.items():cmd+=['--norm-stats',f'{t}={path}']
  with (C/f'{task}.log').open('x') as f:
   child=subprocess.Popen(cmd,env={**env,'CUDA_VISIBLE_DEVICES':str(gpu)},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
  active[task]=child
 deadline=time.monotonic()+3*3600
 while active:
  for task,child in list(active.items()):
   if child.poll() is not None:
    if child.returncode:raise RuntimeError(f'{task} exit {child.returncode}')
    report=json.loads((C/task/'summary.json').read_text());state['completed'].append({'task':task,'successes':report['successes'],'episodes':20});del active[task];save()
  if time.monotonic()>deadline:raise TimeoutError('calibration timeout')
  time.sleep(30)
 reports={t:json.loads((C/t/'summary.json').read_text()) for t in TASKS}
 rows=[{'task':t,'suite':t,'horizon':horizons[t],'episodes':20,'successes':reports[t]['successes'],'simulation_steps':reports[t]['simulation_steps']} for t in TASKS]
 reference={'schema_version':1,'status':'COMPLETE','tasks':rows,'teacher_checkpoints':{t:str(Path(cfg.rollout.expert_models[t].model_path).resolve()) for t in TASKS},'training_signature':training_signature(cfg),'wall_seconds':time.time()-started,'purpose':'Training distribution calibration, seen language, no learned or scripted teacher success screening','simulation_step_unit':'executed_control_targets','source_eval_dir':str(C)}
 path=C/'teacher_reference.json';path.write_text(json.dumps(reference,indent=2)+'\n');state['reference']=load_teacher_reference(str(path),cfg,rows);state['status']='COMPLETE';save()
except BaseException as error:
 state.update(status='FAILED',error=repr(error),traceback=traceback.format_exc());save();raise
finally:
 for child in active.values():
  if child.poll() is None:child.terminate()
 ray.shutdown()
