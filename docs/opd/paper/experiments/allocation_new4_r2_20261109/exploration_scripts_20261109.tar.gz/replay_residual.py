"""Numerical controller replay only: no counterfactual performance prediction."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[4]/'outputs/worktrees/robotwin_allocation_residual'))
from rlinf.utils.rollout_allocation import bounded_quotas
ROOT=Path('/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try');OUT=ROOT/'outputs/robotwin4/allocation_new4_r2_20261109'
sources={'old4_gentle':ROOT/'outputs/robotwin4/formal_sft500_action10_m2_gentle_20261108/training_records/m2/optimizer_updates.jsonl','new4_uniform':OUT/'training_records/action30/uniform/optimizer_updates.jsonl'}
reports={}
for label,path in sources.items():
 if not path.exists():continue
 rows=[]
 for line in path.read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if r['train/refresh/pool_update']==1:rows.append(r)
 keys=[k for k in rows[0] if k.startswith('train/new_rollout_velocity_mse/')] if rows else []
 variants=[]
 for warmup in [3,5]:
  if len(rows)<warmup:continue
  ref={k:sum(r[k] for r in rows[:warmup])/warmup for k in keys}
  for window in [3,5,10]:
   previous=[8]*4;proposals=[]
   for i in range(warmup,len(rows)+1,5):
    recent=rows[max(0,i-window):i];m=[sum(r[k] for r in recent)/len(recent)/max(ref[k],1e-8) for k in keys]
    p=[.5/4+.5*(v+.01)/(sum(m)+4*.01) for v in m];previous=bounded_quotas(p,32,previous,4,4)
    proposals.append({'observed_rounds':i,'normalized_demand':m,'quotas':previous.copy()})
   variants.append({'warmup':warmup,'window':window,'reference':ref,'proposals':proposals})
 reports[label]={'source':str(path),'new_rollout_rows':len(rows),'variants':variants}
(OUT/'offline_residual_replay.json').write_text(json.dumps({'interpretation':'Only numerical stability and allocation behavior; observed data were collected under other allocations. No causal or counterfactual SR claim.','sources':reports},indent=2)+'\n')
print({k:{'rounds':v['new_rollout_rows'],'variants':len(v['variants'])} for k,v in reports.items()})
