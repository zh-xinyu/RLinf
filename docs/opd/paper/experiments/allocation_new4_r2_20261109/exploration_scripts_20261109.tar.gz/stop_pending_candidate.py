import json,os,signal,time
from pathlib import Path
p=Path('/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try/outputs/robotwin4/allocation_new4_r2_20261109/action10_residual_status.json');s=json.loads(p.read_text())
for key,expected in [('pid','run_residual.py'),('child_pid','run_residual_isolated.py')]:
 pid=s[key];cmd=Path(f'/proc/{pid}/cmdline')
 if cmd.exists():
  assert expected in cmd.read_text();os.kill(pid,signal.SIGTERM)
s.update(status='REASSIGNING_GPUS_BEFORE_TRAINING',reason='User requested candidate first; duplicate hardware baseline deferred',stopped_unix=time.time());p.write_text(json.dumps(s,indent=2)+'\n')
print('Stopped duplicate supervisor and sent owned launcher cleanup signal')
