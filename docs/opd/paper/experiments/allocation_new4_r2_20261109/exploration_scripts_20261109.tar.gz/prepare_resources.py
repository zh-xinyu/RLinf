import os,socket,json,subprocess,time,shutil
from pathlib import Path
ROOT=Path('/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try');OUT=ROOT/'outputs/robotwin4/allocation_new4_r2_20261109';host=socket.gethostname().split('.')[0]
runtime=Path('/localscratch/liyifa11/XyFile/opd-robotwin4-action30-20261106' if host=='action30' else '/localscratch/liyifa11/XyFile/opd-robotwin4-action10-20261108')
local=Path('/localscratch2/liyifa11/XyFile/allocation_new4_20261109') if host=='action30' else OUT/'action10_shared'
resources=local/'resources';resources.mkdir(parents=True,exist_ok=True)
state={'host':host,'status':'COPYING','runtime':str(runtime),'local_root':str(local)}
def save():
 state['updated']=time.time();(OUT/f'{host}_resources.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 assert shutil.disk_usage(local).free>450*10**9
 for name,source in [('student',ROOT/'outputs/robotwin4/task_init_probe_20261107/student400_bundle'),('teachers/open_laptop',ROOT/'outputs/robotwin4/task_init_probe_20261107/candidate/torch/open_laptop'),('teachers/dump_bin_bigbin',ROOT/'outputs/robotwin4/task_init_probe_20261107/candidate_dump_bin_bigbin/torch/dump_bin_bigbin')]:
  state['copying']=name;save();dest=resources/name;dest.parent.mkdir(parents=True,exist_ok=True)
  if host=='action10':
   if not dest.exists():dest.symlink_to(source)
  else:
   dest.mkdir(parents=True,exist_ok=True);subprocess.run(['rsync','-a',str(source)+'/',str(dest)+'/'],check=True)
 for task in ['handover_mic','stack_bowls_two']:
  dest=resources/'teachers'/task
  if not dest.exists():dest.symlink_to(runtime/'resources/teachers'/task)
 state.update(status='READY',resources=str(resources));save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e));save();raise
