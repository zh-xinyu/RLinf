import json,os,socket,subprocess,sys,time,shutil,traceback
from pathlib import Path
ROOT=Path('/egr/research-actionlab/liyifa11/XyCode/Intern/Intern_experiments/Pi_OPD_try');OUT=ROOT/'outputs/robotwin4/allocation_new4_r2_20261109';REPO=ROOT/'outputs/worktrees/robotwin_allocation_residual';host=socket.gethostname().split('.')[0]
state={'host':host,'status':'WAITING_RESOURCES','pid':os.getpid(),'method':'normalized_mse_sync_r2','rounds':30}
def save():
 state['updated']=time.time();p=OUT/f'{host}_residual_status.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2)+'\n');t.replace(p)
try:
 save();deadline=time.monotonic()+4*3600
 while True:
  p=OUT/f'{host}_resources.json';r=json.loads(p.read_text())
  if r['status']=='FAILED':raise RuntimeError(r)
  if r['status']=='READY':break
  if time.monotonic()>deadline:raise TimeoutError('resources')
  time.sleep(15)
 runtime=Path(r['runtime']);local=Path(r['local_root']);res=Path(r['resources']);gpus='0,1,2,3' if host=='action30' else '0,3,4,5'
 assert os.environ.get('WANDB_API_KEY'),'W&B credential environment missing'
 tasks=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two'];horizons={'open_laptop':700,'handover_mic':600,'dump_bin_bigbin':600,'stack_bowls_two':900}
 recipe=json.loads((REPO/'toolkits/robotwin_mopd/formal/recipe.json').read_text());overrides=list(recipe['common_overrides'])
 overrides += ['actor.global_batch_size=256','actor.micro_batch_size=8',f'actor.model.model_path={res}/student','+runner.rollout_allocation.demand_signal=normalized_mse','+actor.cuda_cache_retention_gib=22.5','+actor.cuda_cache_preallocate_gib=22','algorithm.flow_refresh_updates=2','algorithm.sync_suite_loss_weights=true','runner.rollout_allocation.mode=adaptive','runner.max_steps=60','runner.save_interval=-1','+runner.save_steps=[20,60]','actor.seed=0','env.train.seed=42','runner.rollout_allocation.seed=42','+rollout.seed=1000000000','runner.logger.wandb_group=allocation_new4_sft400_r2_probe','~rollout.expert_models','+rollout.expert_models={'+','.join(t+':{model_path:'+str(res/'teachers'/t)+'}' for t in tasks)+'}','~actor.model.opd_task_norm_stats','+actor.model.opd_task_norm_stats={'+','.join(t+':'+str(res/'student/assets'/t/'norm_stats.json') for t in tasks)+'}']
 for mode in ['train','eval']:
  overrides += [f'env.{mode}.task_names=['+','.join(tasks)+']',f'~env.{mode}.task_horizons',f'+env.{mode}.task_horizons={{'+','.join(t+':'+str(horizons[t]) for t in tasks)+'}']
 name=f'new4_sft400_normalized_mse_sync_r2_t32_b256_rounds30_seed0_{host}_micro8_retry2'
 command=[sys.executable,str(OUT/'setup/run_residual_isolated.py'),'--run-id',name,'--output-root',str(local/'train'),'--num-gpus','4','--num-cpus','32',*overrides]
 env={**os.environ,'CUDA_VISIBLE_DEVICES':gpus,'GPU_FREE_MB':'46000','TORCHINDUCTOR_COMPILE_THREADS':'1','WANDB_TAGS':f'probe,new4,sft400,normalized-mse,r2,seed0,{host}'}
 (OUT/f'{host}_residual_command.json').write_text(json.dumps(command,indent=2)+'\n')
 with (OUT/f'{host}_residual_dryrun.yaml').open('x') as f:
  subprocess.run(command[:command.index('actor.fsdp_config.enable_gradient_accumulation=false')]+['--dry-run']+overrides,cwd=REPO,env=env,stdout=f,stderr=subprocess.PIPE,check=True)
 state.update(status='RUNNING',run_directory=str(local/'train'/name));save()
 link=OUT/f'{host}_residual_train'
 if not link.exists():link.symlink_to(local/'train'/name)
 with (OUT/f'{host}_residual_train.log').open('x') as log:
  child=subprocess.Popen(command,cwd=REPO,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  state['child_pid']=child.pid;save()
  while child.poll() is None:
   src=local/'train'/name;dst=OUT/'training_records'/host/'residual';dst.mkdir(parents=True,exist_ok=True)
   if src.exists():
    for p in src.iterdir():
     if p.is_file() and p.stat().st_size<50_000_000:
      temp=dst/(p.name+'.tmp');shutil.copyfile(p,temp);temp.replace(dst/p.name)
   save();time.sleep(60)
  if child.returncode:raise RuntimeError(f'training exit {child.returncode}')
 state['status']='COMPLETE';save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());save();raise
