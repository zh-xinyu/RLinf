from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
with (p/'calibration_supervisor.log').open('x') as log:
 c=subprocess.Popen(['bash',str(p/'activate.sh'),str(p/'run_calibration.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(c.pid)
