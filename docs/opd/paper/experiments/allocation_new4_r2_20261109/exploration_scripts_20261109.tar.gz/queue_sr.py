import json,time,subprocess,os
from pathlib import Path
p=Path(__file__).resolve().parent;out=p.parent
state={'status':'WAITING_UNIFORM_AND_CALIBRATION','pid':os.getpid()}
def save():
 state['updated']=time.time();(out/'sr_queue_status.json').write_text(json.dumps(state,indent=2)+'\n')
try:
 save();deadline=time.monotonic()+12*3600
 while True:
  base=json.loads((out/'action30_uniform_status.json').read_text());cal=json.loads((out/'calibration_action30/status.json').read_text()) if (out/'calibration_action30/status.json').exists() else {'status':'STARTING'}
  if base['status']=='FAILED' or cal['status']=='FAILED':raise RuntimeError({'uniform':base['status'],'calibration':cal})
  if base['status']=='COMPLETE' and cal['status']=='COMPLETE':break
  if time.monotonic()>deadline:raise TimeoutError('SR queue wait')
  time.sleep(60)
 state['status']='RUNNING';save()
 with (p/'sr_supervisor.log').open('x') as log:
  child=subprocess.Popen(['bash',str(p/'activate.sh'),str(p/'run_sr.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
  state['child_pid']=child.pid;save();code=child.wait()
 if code:raise RuntimeError(f'SR supervisor exit {code}')
 state['status']='COMPLETE';save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e));save();raise
