"""Fixed development-only evaluation queue, standard workers, one persistent owner."""
import json,os,socket,subprocess,sys,tempfile,time,traceback
from pathlib import Path
import ray
from omegaconf import OmegaConf
S=Path(__file__).resolve().parent;OUT=S.parent;D=OUT/'development_action30_matched';D.mkdir(exist_ok=True);TASKS=['open_laptop','handover_mic','dump_bin_bigbin','stack_bowls_two'];REPO=Path(os.environ['REPO_PATH']);active={}
state={'status':'RESUMING','pid':os.getpid(),'completed':[json.loads((D/label/'summary.json').read_text()) for label in ['teachers','initial400']]}
def save():
 state['updated']=time.time();(D/'status.json').write_text(json.dumps(state,indent=2)+'\n')
def evaluate(label,checkpoints,env,pool,cfg):
 state['status']='EVALUATING';state['current']=label;save()
 for gpu,task in enumerate(TASKS):
  destination=D/label/task
  cmd=[sys.executable,str(REPO/'toolkits/robotwin_mopd/worker_evaluate.py'),'--task',task,'--tasks',*TASKS,'--pool',str(pool),'--checkpoint',str(checkpoints[task]),'--episodes','20','--gpu',str(gpu),'--output',str(destination)]
  for t,p in cfg.actor.model.opd_task_norm_stats.items():cmd+=['--norm-stats',f'{t}={p}']
  destination.parent.mkdir(exist_ok=True)
  with (D/f'{label}_{task}.log').open('x') as f:
   child=subprocess.Popen(cmd,env={**env,'CUDA_VISIBLE_DEVICES':str(gpu)},stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
  active[task]=child
 while active:
  for task,child in list(active.items()):
   if child.poll() is not None:
    if child.returncode:raise RuntimeError(f'{label}/{task} failed: {child.returncode}')
    del active[task]
  time.sleep(30)
 reports={t:json.loads((D/label/t/'summary.json').read_text()) for t in TASKS}
 scores={t:r['successes']/20 for t,r in reports.items()}
 report={'label':label,'task_sr':scores,'macro_sr':sum(scores.values())/4,'episodes_per_task':20,'control_steps':sum(r['simulation_steps'] for r in reports.values())}
 if label!='teachers':
  teachers=json.loads((D/'teachers/summary.json').read_text())['task_sr'];gaps={t:max(0,teachers[t]-scores[t]) for t in TASKS};report.update(positive_teacher_gaps=gaps,max_teacher_gap=max(gaps.values()),all_within_delta_010=all(scores[t]>=teachers[t]-.1 for t in TASKS))
 (D/label/'summary.json').write_text(json.dumps(report,indent=2)+'\n');state['completed'].append(report);save()
try:
 assert socket.gethostname().split('.')[0]=='action30';save()
 cfg=OmegaConf.load(OUT/'action30_uniform_train/resolved_config.yaml');pool=D/'development20.json'
 # Serialize evaluation cohorts so two 4-task services do not overlap GPU peaks.
 wait_deadline=time.monotonic()+18*3600
 while True:
  try:
   previous=json.loads((OUT/'development_action30/status.json').read_text())
   pid=previous.get('pid');cmd=Path(f'/proc/{pid}/cmdline')
   alive=cmd.exists() and b'run_development_eval_resume.py' in cmd.read_bytes()
   if previous['status'] in ['COMPLETE','FAILED'] and not alive:break
  except (json.JSONDecodeError,FileNotFoundError,ProcessLookupError):
   pass
  state.update(status='WAITING_PREVIOUS_EVALUATOR',current=None);save()
  if time.monotonic()>wait_deadline:raise TimeoutError('previous evaluation owner did not finish')
  time.sleep(60)
 context=ray.init(address='local',namespace='allocation-dev-eval-matched-owner',num_cpus=12,num_gpus=4,object_store_memory=2*1024**3,include_dashboard=False,_temp_dir=tempfile.mkdtemp(prefix='rwt-dev-'))
 env={**os.environ,'RAY_ADDRESS':context.address_info['gcs_address'],'OMP_NUM_THREADS':'1','MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','TORCHINDUCTOR_COMPILE_THREADS':'1'}
 pending=[('residual_matched',10),('residual_matched',30)];deadline=time.monotonic()+18*3600
 while pending:
  ready=[]
  for method,round_ in pending:
   host='action10' if method=='residual' else 'action30';status=OUT/f'{host}_{method}_status.json'
   if not status.exists():continue
   record=json.loads(status.read_text())
   if record['status']=='FAILED':continue
   run=Path(record.get('run_directory',''));directory=run/run.name/'checkpoints'/f'global_step_{round_*2}'
   # Runner state is written after complete actor+optimizer checkpoint save.
   if (directory/'runner_state.json').is_file() and (directory/'actor/dcp_checkpoint/.metadata').is_file():ready.append((method,round_,directory))
  if ready:
   method,round_,checkpoint=ready[0];evaluate(f'{method}_round{round_}',{t:checkpoint for t in TASKS},env,pool,cfg);pending.remove((method,round_))
  else:
   state.update(status='WAITING_CHECKPOINTS',pending=pending,current=None);save();time.sleep(60)
  if time.monotonic()>deadline:raise TimeoutError('development evaluation wait')
 state.update(status='COMPLETE',current=None);save()
except BaseException as e:
 state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc());save();raise
finally:
 for child in active.values():
  if child.poll() is None:child.terminate()
 ray.shutdown()
