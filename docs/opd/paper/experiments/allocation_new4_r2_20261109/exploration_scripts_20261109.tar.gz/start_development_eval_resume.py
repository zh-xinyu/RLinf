from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
with (p/'development_supervisor_resume.log').open('x') as log:
 c=subprocess.Popen(['bash',str(p/'activate.sh'),str(p/'run_development_eval_resume.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(c.pid)
