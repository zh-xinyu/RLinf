from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
with (p/'residual_matched_supervisor_action30.log').open('x') as log:
 child=subprocess.Popen(['bash',str(p/'activate_residual.sh'),str(p/'run_residual_matched_action30.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(child.pid)
