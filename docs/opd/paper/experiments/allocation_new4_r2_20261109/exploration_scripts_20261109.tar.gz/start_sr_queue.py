from pathlib import Path
import subprocess
p=Path(__file__).resolve().parent
with (p/'sr_queue.log').open('x') as log:
 c=subprocess.Popen(['python3',str(p/'queue_sr.py')],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
print(c.pid)
